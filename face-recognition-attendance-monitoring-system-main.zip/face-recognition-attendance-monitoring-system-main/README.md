please change all path's according to you
